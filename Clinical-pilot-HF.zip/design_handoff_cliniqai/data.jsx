/* ============================ CliniqAI mock data ============================ */

const PATIENTS = [
  { id: "p-001", name: "Anjali Rao", age: 54, sex: "F", ward: "Gen Med A", bed: "A-12" },
  { id: "p-002", name: "Rohit Sharma", age: 61, sex: "M", ward: "Cardiac", bed: "C-04" },
  { id: "p-003", name: "Meera Iyer", age: 38, sex: "F", ward: "Gen Med A", bed: "A-07" },
  { id: "p-004", name: "Sandeep Nair", age: 72, sex: "M", ward: "Gen Med B", bed: "B-15" },
];

/* ---- Doctor: the AI-drafted SOAP note ---- */
const SOAP_DRAFT = {
  patient: "p-001",
  model: "qwen3-32b",
  confidence: 92,
  referral: false,
  durationSec: 41,
  fields: {
    subjective:
      "54F with known essential hypertension presents for routine follow-up. Reports intermittent occipital headaches over the past 2 weeks, worse in the mornings. Denies chest pain, palpitations, visual disturbance, or dyspnoea. Adherent to amlodipine 5 mg OD. No new medications. Non-smoker.",
    objective:
      "BP 158/96 mmHg (repeat 154/94), HR 78 bpm regular, afebrile, SpO2 98% RA. BMI 27.4. CVS: S1 S2 normal, no murmurs. Chest clear. No pedal oedema. Fundoscopy: no papilloedema. Recent labs: serum creatinine 0.9 mg/dL, K+ 4.1 mmol/L.",
    assessment:
      "Essential hypertension, sub-optimally controlled on monotherapy. No evidence of end-organ damage or hypertensive emergency. Headache likely tension-type, correlating with raised readings.",
    plan:
      "1. Up-titrate amlodipine to 10 mg OD. 2. Add home BP monitoring; target <140/90. 3. Reinforce sodium restriction and weight management. 4. Review in 4 weeks; if uncontrolled, add ACE-inhibitor. 5. Safety-net for visual changes / severe headache.",
  },
  icd: [
    { code: "I10", label: "Essential (primary) hypertension", conf: 0.96 },
    { code: "R51", label: "Headache", conf: 0.71 },
  ],
  citations: [
    { src: "MoHFW — Standard Treatment Guidelines: Hypertension", loc: "p. 44", tag: "wiki" },
    { src: "ICMR — STW Vol 3 (2022)", loc: "p. 18", tag: "rag" },
    { src: "Patient wiki — anjali-rao.md", loc: "§ History", tag: "wiki" },
  ],
};

/* ---- Patient: WhatsApp-style chat ---- */
const CHAT_SEED = [
  { from: "bot", time: "09:02", text: "Hi Anjali 👋 This is CliniqAI from Apollo Clinic. How can I help with your appointment today?" },
  { from: "user", time: "09:03", text: "I need to see Dr. Khanna sometime this week" },
  { from: "bot", time: "09:03", text: "Dr. Khanna (Cardiology) has these open slots:", slots: ["Wed 12 Jun · 10:30 AM", "Thu 13 Jun · 4:00 PM", "Fri 14 Jun · 11:15 AM"] },
  { from: "user", time: "09:04", text: "Thursday afternoon works" },
  { from: "bot", time: "09:04", text: "Booked ✅ Thu 13 Jun · 4:00 PM with Dr. Khanna. A confirmation email is on its way and I'll remind you 24 h before. Anything else?", confirm: { doctor: "Dr. Khanna", when: "Thu 13 Jun · 4:00 PM", ref: "apt-7741" } },
];
const QUICK_ACTIONS = [
  { icon: "calendar", label: "Book", reply: "I'd like to book a new appointment" },
  { icon: "x", label: "Cancel", reply: "I need to cancel my appointment" },
  { icon: "refresh", label: "Reschedule", reply: "Can I reschedule to another day?" },
];

/* ---- Nurse: handover ---- */
const HANDOVER = [
  { bed: "C-04", priority: "urgent", id: "p-002", name: "Rohit Sharma", one: "Post-MI day 2, troponin trending down, on heparin infusion.", pending: ["Repeat troponin 22:00", "Cardiology review"] },
  { bed: "B-15", priority: "urgent", id: "p-004", name: "Sandeep Nair", one: "CAP, sats 91% on 2L O2, due IV antibiotics.", pending: ["ABG", "Chase blood cultures"] },
  { bed: "A-12", priority: "watch", id: "p-001", name: "Anjali Rao", one: "HTN follow-up, BP 154/94, started amlodipine 10 mg.", pending: ["Recheck BP 20:00"] },
  { bed: "A-07", priority: "watch", id: "p-003", name: "Meera Iyer", one: "Migraine, settling on analgesia, observe.", pending: ["Reassess pain score"] },
  { bed: "B-09", priority: "stable", id: "p-006", name: "Vikram Bose", one: "T2DM review, glucose stable, awaiting discharge meds.", pending: [] },
  { bed: "A-03", priority: "stable", id: "p-007", name: "Fatima Sheikh", one: "Cellulitis improving, oral switch done.", pending: [] },
];

/* ---- Nurse: roster ---- */
const ROSTER = [
  { id: "sh-3301", day: "Mon 09 Jun", shift: "Day",   staff: "N. Pillai",   role: "RN",  start: "07:00", end: "15:00", cover: false },
  { id: "sh-3302", day: "Mon 09 Jun", shift: "Eve",   staff: "S. Banerjee", role: "RN",  start: "15:00", end: "23:00", cover: false },
  { id: "sh-3303", day: "Mon 09 Jun", shift: "Night", staff: "K. Reddy",    role: "RN",  start: "23:00", end: "07:00", cover: true  },
  { id: "sh-3304", day: "Tue 10 Jun", shift: "Day",   staff: "A. George",   role: "CN",  start: "07:00", end: "15:00", cover: false },
  { id: "sh-3305", day: "Tue 10 Jun", shift: "Eve",   staff: "N. Pillai",   role: "RN",  start: "15:00", end: "23:00", cover: false },
  { id: "sh-3306", day: "Tue 10 Jun", shift: "Night", staff: "D. Kapoor",   role: "RN",  start: "23:00", end: "07:00", cover: false },
  { id: "sh-3307", day: "Wed 11 Jun", shift: "Day",   staff: "S. Banerjee", role: "RN",  start: "07:00", end: "15:00", cover: false },
  { id: "sh-3308", day: "Wed 11 Jun", shift: "Eve",   staff: "A. George",   role: "CN",  start: "15:00", end: "23:00", cover: false },
];

/* ---- Nurse: discharge fan-out ---- */
const DISCHARGE = [
  { stream: "Discharge summary", status: "done",     note: "Drafted from wiki + SOAP, signed by Dr. Khanna." },
  { stream: "Pharmacy",          status: "progress", note: "TTO meds queued; awaiting stock confirmation." },
  { stream: "Family notification", status: "done",   note: "SMS + email sent to next of kin." },
  { stream: "Follow-up booking", status: "approve",  note: "Slot proposed: 18 Jun — awaiting approval." },
  { stream: "Billing",           status: "queued",   note: "Blocked on pharmacy total." },
];

/* ---- Nurse: wiki health ---- */
const WIKI_HEALTH = [
  { page: "hypertension.md", status: "ok",    note: "Current — synced to MoHFW STG.", updated: "2 days ago" },
  { page: "type2-diabetes.md", status: "stale", note: "ICMR 2018 source; newer 2023 guidance available.", updated: "94 days ago" },
  { page: "anjali-rao.md",   status: "ok",    note: "Updated on last consult approval.", updated: "Today" },
  { page: "amlodipine.md",   status: "broken", note: "Broken cross-ref → 'ace-inhibitors.md' (missing).", updated: "12 days ago" },
];

Object.assign(window, {
  PATIENTS, SOAP_DRAFT, CHAT_SEED, QUICK_ACTIONS,
  HANDOVER, ROSTER, DISCHARGE, WIKI_HEALTH,
});
