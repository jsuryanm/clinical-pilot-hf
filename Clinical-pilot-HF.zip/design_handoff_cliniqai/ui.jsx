/* ===================== CliniqAI — shared UI atoms & shell ===================== */
const { useState, useRef, useEffect } = React;

/* ---------- icon set (stroke, 1.7) ---------- */
const ICON = {
  stethoscope: "M6 3v6a4 4 0 0 0 8 0V3M4.5 3h3M12.5 3h3M10 17a4 4 0 0 0 4-4M20 15a2 2 0 1 1-4 0 2 2 0 0 1 4 0Z",
  chat: "M21 11.5a8.4 8.4 0 0 1-8.5 8.4 9 9 0 0 1-3.9-.9L3 21l1.9-5.1A8.4 8.4 0 1 1 21 11.5Z",
  clipboard: "M9 4h6a1 1 0 0 1 1 1v1H8V5a1 1 0 0 1 1-1ZM8 6H6a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V7a1 1 0 0 0-1-1h-2M9 12h6M9 16h4",
  sun: "M12 4V2M12 22v-2M4 12H2M22 12h-2M6 6 4.5 4.5M19.5 19.5 18 18M18 6l1.5-1.5M4.5 19.5 6 18M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8Z",
  moon: "M21 12.8A8.5 8.5 0 1 1 11.2 3a6.6 6.6 0 0 0 9.8 9.8Z",
  mic: "M12 3a3 3 0 0 0-3 3v5a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3ZM6 11a6 6 0 0 0 12 0M12 17v4M9 21h6",
  upload: "M12 16V4m0 0L7.5 8.5M12 4l4.5 4.5M5 20h14",
  check: "M5 12.5 10 17.5 19.5 7",
  x: "M6 6l12 12M18 6 6 18",
  calendar: "M7 3v3M17 3v3M4 8h16M5 6h14a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1Z",
  refresh: "M4 10a8 8 0 0 1 13.5-4L20 8M20 14a8 8 0 0 1-13.5 4L4 16M20 4v4h-4M4 20v-4h4",
  send: "M5 12l14-7-5 16-3.5-6L5 12Z",
  spark: "M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3Z",
  alert: "M12 9v4m0 4h.01M10.3 4.3 2.6 18a2 2 0 0 0 1.7 3h15.4a2 2 0 0 0 1.7-3L13.7 4.3a2 2 0 0 0-3.4 0Z",
  clock: "M12 7v5l3 2M12 21a9 9 0 1 1 0-18 9 9 0 0 1 0 18Z",
  copy: "M9 9h9a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H9a1 1 0 0 1-1-1v-9a1 1 0 0 1 1-1ZM5 15H4a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h9a1 1 0 0 1 1 1v1",
  link: "M10 13a4 4 0 0 0 5.7 0l2.6-2.6a4 4 0 0 0-5.7-5.7L11 6M14 11a4 4 0 0 0-5.7 0l-2.6 2.6a4 4 0 1 0 5.7 5.7L13 18",
  users: "M16 19a4 4 0 0 0-8 0M12 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7ZM20 19a3.5 3.5 0 0 0-3-3.5M18 11a2.5 2.5 0 0 0 0-5",
  doc: "M14 3v4a1 1 0 0 0 1 1h4M15 3H7a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h11a1 1 0 0 0 1-1V8l-4-5ZM9 13h6M9 17h6",
  pill2: "M10.5 13.5 13.5 10.5M8 16a4 4 0 0 1 0-5.7l2.3-2.3a4 4 0 1 1 5.7 5.7L13.7 16A4 4 0 0 1 8 16Z",
  bell: "M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0",
  rupee: "M8 5h8M8 9h8M14 5c0 4-2 6-6 6h1l5 7",
};

function Icon({ name, size = 18, color = "currentColor", stroke = 1.7 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke={color} strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
      <path d={ICON[name]} />
    </svg>
  );
}

/* ---------- illustrated quill mascot ---------- */
function Quill({ size = 30 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
      <defs>
        <linearGradient id="qfeather" x1="6" y1="4" x2="26" y2="26" gradientUnits="userSpaceOnUse">
          <stop stopColor="#eaf4ff" />
          <stop offset="1" stopColor="#bcd9ff" />
        </linearGradient>
      </defs>
      {/* feather body */}
      <path d="M25.5 5.2C18 4.4 9.6 8.2 7.4 16.8c-.7 2.6-.5 5 .2 6.9L23 8.3c.5-.5 1.3.2.9.8L9.9 24.6c1.8.8 4.2 1 6.8.3 8.6-2.3 12.4-10.8 11.6-18.3a1.4 1.4 0 0 0-2.8-.4Z"
        fill="url(#qfeather)" stroke="#ffffff" strokeWidth="0.8" strokeLinejoin="round" />
      {/* central rachis */}
      <path d="M23.6 8.2 9 23.4" stroke="#5b8fe0" strokeWidth="1.1" strokeLinecap="round" />
      {/* barbs */}
      <path d="M22 10.5l-3.2-.5M19.4 13.2l-3.4-.7M16.6 16l-3.5-.6M13.8 18.8l-3.3-.5" stroke="#7fa9e8" strokeWidth="0.9" strokeLinecap="round" />
      {/* nib tip + ink drop */}
      <path d="M9 23.4 6.2 26.2" stroke="#dbeaff" strokeWidth="1.6" strokeLinecap="round" />
      <circle cx="5.4" cy="27" r="1.5" fill="#7dd3fc" />
    </svg>
  );
}

/* ---------- atoms ---------- */
function Pill({ kind, dot, children }) {
  return <span className={"pill pill-" + kind}>{dot && <span className="pdot" style={{ background: "currentColor" }} />}{children}</span>;
}

function IDToken({ children }) {
  const [copied, setCopied] = useState(false);
  return (
    <span className={"idtok" + (copied ? " copied" : "")} title="Click to copy"
      onClick={() => { navigator.clipboard?.writeText(children).catch(() => {}); setCopied(true); setTimeout(() => setCopied(false), 1100); }}>
      {copied ? "copied" : children}
    </span>
  );
}

function Banner({ kind = "ok", icon, children }) {
  const ic = { ok: "check", warn: "alert", err: "x", info: "spark" }[kind];
  return (
    <div className={"banner banner-" + kind}>
      <span className="banner-ico"><Icon name={icon || ic} size={18} /></span>
      <span>{children}</span>
    </div>
  );
}

function Btn({ kind = "primary", icon, children, className = "", ...rest }) {
  return (
    <button className={`btn btn-${kind} ${className}`} {...rest}>
      {icon && <Icon name={icon} size={16} />}{children}
    </button>
  );
}

function ConfBar({ value }) {
  const tone = value >= 85 ? "var(--success)" : value >= 65 ? "var(--warning)" : "var(--danger)";
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
      <div style={{ flex: 1, height: 8, borderRadius: 999, background: "var(--surface-3)", overflow: "hidden" }}>
        <div style={{ width: value + "%", height: "100%", background: tone, borderRadius: 999, transition: "width .8s cubic-bezier(.2,.8,.2,1)" }} />
      </div>
      <span style={{ fontFamily: "var(--font-mono)", fontWeight: 700, fontSize: 13, color: tone }}>{value}%</span>
    </div>
  );
}

/* ---------- top nav shell (matches the marketing site) ---------- */
const SURFACES = [
  { id: "doctor",  label: "Doctor",        icon: "stethoscope", count: "1 draft" },
  { id: "patient", label: "Patient",       icon: "chat",        count: null },
  { id: "nurse",   label: "Nurse & Admin", icon: "clipboard",   count: "6 beds" },
];

function TopNav({ active, setActive, theme, onToggle }) {
  return (
    <div className="appnav">
      <div className="appnav-in">
        <a className="appbrand" href="CliniqAI.html" title="CliniqAI">
          <span className="mascot-badge"><Quill size={22} /></span>Cliniq<span className="ai">AI</span>
        </a>
        <div className="navtabs">
          {SURFACES.map(s => (
            <button key={s.id} className={"navtab" + (active === s.id ? " on" : "")} onClick={() => setActive(s.id)}>
              <Icon name={s.icon} size={16} />{s.label}
              {s.count && <span className="cnt">{s.count}</span>}
            </button>
          ))}
        </div>
        <div className="navright">
          <span className="status-pill"><span className="live-dot" />API online · v0.4</span>
          <button className="theme-toggle" onClick={onToggle} title="Toggle theme" aria-label="Toggle theme">
            <Icon name={theme === "dark" ? "sun" : "moon"} size={17} />
          </button>
        </div>
      </div>
    </div>
  );
}

function Intro({ icon, title, children, tag }) {
  return (
    <div className="intro">
      <div className="intro-icon"><Icon name={icon} size={22} /></div>
      <div className="grow">
        <div className="row aic gap-10">
          <h2>{title}</h2>
          {tag === "ship" && <span className="ship-tag">Shipping</span>}
          {tag === "soon" && <span className="soon-tag">Coming soon</span>}
        </div>
        <p>{children}</p>
      </div>
    </div>
  );
}

Object.assign(window, { Icon, Quill, Pill, IDToken, Banner, Btn, ConfBar, TopNav, Intro });
