# Handoff: CliniqAI — Clinical Operations Web App

## Overview
CliniqAI is an AI co-pilot for the **administrative** layer of hospital work — clinical
documentation, patient appointments, and duty rostering — built for Indian hospitals.
Clinicians stay in control of every clinical decision; the AI only ever produces **drafts**
a human edits and approves.

This bundle is a high-fidelity design reference for the product's web UI: one app shell with
a top navigation and three persona **surfaces** — **Doctor**, **Patient**, and **Nurse & Admin**
— plus light and dark themes.

## About the Design Files
The files in this bundle are **design references created in HTML/React (Babel-in-browser) + CSS**.
They are prototypes that demonstrate the intended look, layout, and interactions — **not**
production code to ship as-is.

Your task is to **recreate these designs in the target codebase's environment**. The current
product is built in **Gradio (Python)**; these references show where to take it visually. Recreate
the look using the target stack's established patterns — whether that stays Gradio (custom theme +
CSS), or moves to a React/Next frontend against the existing FastAPI backend. Treat the HTML as the
source of truth for *appearance and behavior*, and the design tokens below as the contract.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, radii, shadows, and interaction states
are all specified here and in `styles.css` / `surfaces.css` as CSS custom properties. Recreate the
UI to match, using the codebase's own component primitives.

---

## Screens / Views

The app is a single shell: a sticky **top navigation bar** + a centered content column
(`max-width: 1140px`). The top nav holds the brand (quill mascot + "CliniqAI" wordmark), three
surface tabs (Doctor · Patient · Nurse & Admin, each with an optional count badge), and on the
right a live "API online · v0.4" status pill and a light/dark theme toggle.

Each surface opens with a **page header**: a 46×46 rounded icon tile, an `h2` title whose second
word is set in *Newsreader italic* (the serif accent — e.g. "Consultation **documentation**"), a
green "Shipping" tag, and a muted one-line description.

### 1. Doctor — Consultation Documentation  (`doctor.jsx`)
- **Purpose:** turn a spoken/typed consult into an approved SOAP note in <60s.
- **Layout:** two columns — `grid-template-columns: 360px 1fr; gap: 18px` (stacks to 1 column
  below 900px).
  - **Left card "Consult input":** patient-ID `<select>` (mono font) + patient meta pills; a
    3-way segmented control **Record / Upload / Transcript**; the active source's body (an audio
    "recording" row with a faux waveform, a dashed drop zone, or a transcript textarea); a full-width
    primary **"Draft SOAP note"** button; a caption "Qwen3-32B on Groq · avg 41s".
  - **Right column:** a status **Banner** ("Draft ready…"), a **SOAP note** card with a copyable
    mono draft-ID and a "draft" pill, then four editable fields **S / O / A / P** — each row is a
    colored 30×30 letter tile (`S #2563eb`, `O #0891b2`, `A #7c3aed`, `P #0ea672`) beside a label +
    `<textarea>`. Below: a **Confidence & citations** card (confidence progress bar with %, a
    referral-status pill, ICD-10 chips with per-code confidence, and a list of source citations
    tagged "LLM wiki" / "RAG"). Footer actions: **Approve & file to wiki** (success) + **Reject**.
- **Key states:** clicking *Draft* runs a 4-step loading sequence (transcribe → read wiki → retrieve
  → draft) with a progress bar, then reveals the draft. *Approve* swaps the banner to a written-to-wiki
  confirmation. *Reject* re-runs the draft.

### 2. Patient — Appointment Assistant  (`patient.jsx`)
- **Purpose:** book / change / cancel an appointment conversationally (WhatsApp-style; Twilio in prod).
- **Layout:** `grid-template-columns: 380px 1fr; gap: 24px` — a fixed **phone frame** (380×620,
  `border-radius: 26px`) on the left, an explainer column on the right.
  - **Phone:** a navy chat header (avatar + "CliniqAI · Apollo Clinic" + online dot); a scrolling
    thread of chat bubbles (bot = white left-aligned, user = blue gradient right-aligned, with
    timestamps); bot messages can carry **slot buttons** and a green **confirmation card**; a row of
    **quick-action chips** (Book / Cancel / Reschedule); a composer (rounded input + circular send).
  - **Right column:** "Conversational, by design" + three feature rows (calendar / reminders / waitlist).
- **Key states:** typing a message or tapping a quick-action appends a user bubble, shows a 3-dot
  typing indicator (~1.1s), then a keyword-based bot reply. Thread auto-scrolls to the newest message.

### 3. Nurse & Admin — Operations Console  (`nurse.jsx`)
- **Purpose:** run handover, rostering, discharge, and wiki health from one dense console.
- **Layout:** a **sub-navigation** pill bar (Handover · Roster · Discharge · Wiki health; non-shipping
  items carry a small amber dot), then the active sub-view. Rostering is the shipping hero; the others
  are "coming soon" teasers.
  - **Handover:** ward `<select>` + "Generate brief" → an empty state, then a priority-sorted patient
    table (bed, **priority pill** urgent→watch→stable, patient + mono ID, one-line summary, pending-
    action chips). Sticky header, zebra rows.
  - **Roster (shipping):** a "Generate roster" card (CSV path token, a day-window range slider 7–28,
    primary button) beside a **fairness-score ring** (conic-gradient donut). Below: a 14-day roster
    table (mono shift-IDs, shift pills, staff, role, mono start/end, cover pill). A **sick-call
    replacement** sub-form (shift-ID + absent-staff inputs → "Find replacement" → success banner).
  - **Discharge (teaser):** patient-ID input + "Start discharge" → a grid of 5 parallel **stream cards**
    (Summary · Pharmacy · Family · Follow-up · Billing) each with a left status accent, status icon,
    and status pill (done / in-progress / queued / failed / awaiting-approval).
  - **Wiki health (teaser):** a lint table of knowledge pages (mono page name, status pill ok/stale/
    broken, detail, last-updated).

See `screenshots/` for rendered references of each surface (light) plus a dark-mode example.

---

## Interactions & Behavior
- **Top-nav tabs:** switch surfaces; active tab = `--accent-soft` background, `--blue-700` text. The
  active surface persists to `localStorage["cq_tab"]`.
- **Theme toggle:** flips `data-theme="light|dark"` on `<html>`; persists to `localStorage["cq_theme"]`.
- **ID tokens** (mono, tinted): click to copy to clipboard; briefly flips to a green "copied" state.
- **Draft flow (Doctor):** staged progress (4 × ~600ms) gated behind a disabled button label "Drafting…".
- **Chat (Patient):** typing indicator ~1100ms before the reply; thread auto-scrolls; quick-action chips
  inject canned user turns.
- **Transitions:** surface change fades content in (`fadeIn .4s`); chat bubbles pop in
  (`pop .3s cubic-bezier(.2,.9,.3,1.2)`); confidence bars animate width
  (`.8s cubic-bezier(.2,.8,.2,1)`); discharge cards stagger by 90ms; buttons lift on hover and depress
  on `:active`. All entrance animation is decorative — base state is the visible end-state.
- **Responsive:** Doctor two-column stacks <900px; Patient phone+aside stacks <860px; top-nav reflows
  (tabs become a horizontal scroll row) <720px.

## State Management
Per surface (React `useState` in the prototypes):
- **Doctor:** `stage` (idle | loading | draft), `pid`, `source` (audio|upload|text), `fields`
  {subjective, objective, assessment, plan}, `progress` (0–100), `approved`.
- **Patient:** `msgs[]` (append-only thread), `text`, `typing`.
- **Nurse:** active `sub` tab; Handover `generated`; Roster `days`, `shiftId`, `absent`, `resolved`;
  Discharge `run`.
- **App shell:** `theme`, `active` surface — both persisted to `localStorage`.
In production, replace the canned data in `data.jsx` with the FastAPI JSON responses; each agent
returns a validated Pydantic model (`SOAPNoteDraft`, `BookingResult`, `RosterResult`, …).

## Design Tokens
All tokens are CSS custom properties in `styles.css` (`:root` = light, `[data-theme="dark"]` = dark).

### Color — light
| Role | Token | Hex |
|---|---|---|
| Primary accent | `--blue-600` | `#2563eb` |
| Primary hover | `--blue-700` | `#1d4ed8` |
| Accent (light) | `--blue-500` / `--sky-500` | `#3b82f6` / `#38bdf8` |
| Mascot gradient | `--grad-mascot` | `linear-gradient(150deg,#3b82f6,#1e3a8a)` |
| Text primary | `--ink` | `#0b1f44` |
| Text secondary | `--ink-2` | `#44567a` |
| Text muted | `--muted` / `--muted-2` | `#6b7d9e` / `#93a3c0` |
| Canvas | `--canvas` | `#f5f8fe` |
| Surface / card | `--surface` | `#ffffff` |
| Subtle fills | `--surface-2` / `--surface-3` | `#f6f9ff` / `#eef4ff` |
| Border | `--border` / `--border-2` | `#dce6f5` / `#cbd9ee` |
| Accent fills | `--accent-soft` / `--accent-softer` | `#e2edff` / `#eef4ff` |
| Success | `--success` / `--success-bg` | `#0ea672` / `#d6f5e8` |
| Warning | `--warning` / `--warning-bg` | `#e08a00` / `#fdeecb` |
| Danger | `--danger` / `--danger-bg` | `#e23b48` / `#fbdfe1` |
| Info fill | `--info-bg` | `#dcebff` |

### Color — dark (`[data-theme="dark"]`)
Canvas `#060c1c` · surface `#0f1b34` · surface-2 `#142242` · surface-3 `#18294c` ·
border `#21345c` / `#2c4170` · ink `#eaf1ff` · ink-2 `#adbcd6` · muted `#7d8eb0`.
Accent blues and semantic hues are preserved; semantic backgrounds become low-alpha tints.

### Typography
| Family | Token | Use |
|---|---|---|
| Plus Jakarta Sans (500–800) | `--font-head` | wordmark, headings, buttons, labels, tabs |
| Inter (400–700) | `--font-body` | body copy, descriptions |
| Newsreader *italic* (500/600) | `--font-serif` | the accent word in each page-header `h2` |
| JetBrains Mono (500–700) | `--font-mono` | IDs, ICD codes, shift IDs, times, file paths |

Scale: nav brand 18/800 · nav tab 14/600 · page-header h2 **27/800** (serif accent 27 italic 500) ·
card-head h3 15/700 · body 13.5–14 · field label 12.5/650 · captions 11.5–12 · mono IDs ~12.
Wordmark/headers use tight tracking (`letter-spacing: -.025em`).

### Radius
`--r-sm 9px` · `--r-md 11px` · `--r-lg 14px` · `--r-xl 16px` · pills `999px` · phone frame `26px`.

### Shadow
`--sh-sm 0 1px 2px rgba(11,31,68,.05)` ·
`--sh-md 0 6px 22px -10px rgba(13,40,100,.15)` ·
`--sh-lg 0 22px 54px -26px rgba(13,40,100,.36)` ·
`--sh-glow 0 6px 16px -8px rgba(37,99,235,.42)` (primary buttons).

### Spacing / layout
Content column `max-width: 1140px`, `padding: 40px 26px 64px`. Card padding 20px. Common gaps 8–24px
via flex/grid `gap`. Top-nav min-height 66px.

## Assets
- **Quill mascot** — an inline SVG (a stylized feather + nib + ink drop) in `ui.jsx` (`Quill`
  component), shown in a `--grad-mascot` rounded badge. No external image; recolors with theme.
- **Icon set** — single-path stroke SVGs (1.7 stroke) defined in `ui.jsx` (`ICON` map / `Icon`
  component): stethoscope, chat, clipboard, mic, upload, check, x, calendar, refresh, send, spark,
  alert, clock, users, doc, link, bell, etc. Equivalent to Lucide icons — swap for your icon library.
- **Fonts** — Google Fonts: Plus Jakarta Sans, Inter, Newsreader (italic), JetBrains Mono.
- **No raster images.** All "imagery" is CSS/SVG; the audio waveform and fairness ring are pure CSS.

## Files
All design source is in this bundle (recreate, don't ship directly):
- `CliniqAI.html` — entry; loads fonts, `styles.css`, `surfaces.css`, then the JSX modules.
- `styles.css` — tokens (light/dark), app chrome (top nav), atoms (buttons, pills, banners, inputs,
  tables, ID tokens), page header.
- `surfaces.css` — surface-specific styles (Doctor two-column + SOAP, Patient phone/chat, Nurse
  sub-nav/roster/discharge/wiki).
- `data.jsx` — canned demo data for all surfaces (replace with API responses).
- `ui.jsx` — shared shell + atoms: `Icon`, `Quill`, `Pill`, `IDToken`, `Banner`, `Btn`, `ConfBar`,
  `TopNav`, `Intro`.
- `doctor.jsx` · `patient.jsx` · `nurse.jsx` — the three surfaces.
- `screenshots/` — rendered references: `01-doctor-light`, `02-patient-light`,
  `03-nurse-roster-light`, `04-doctor-dark`.

> Note on the screenshots: a couple show the serif accent word slightly clipped by the adjacent
> "Shipping" tag — that is a screenshot-renderer artifact only; in a real browser the header is a
> clean single line (the live prototype confirms this).
