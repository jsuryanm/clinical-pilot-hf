/* ===================== CliniqAI — Doctor surface ===================== */

function SoapField({ letter, name, value, onChange }) {
  const colors = { S: "#2563eb", O: "#0891b2", A: "#7c3aed", P: "#0ea672" };
  return (
    <div className="soap-field">
      <div className="soap-tab" style={{ background: colors[letter] }}>{letter}</div>
      <div className="grow">
        <label className="field-label" style={{ marginBottom: 5 }}>{name}</label>
        <textarea className="textarea" rows={letter === "P" ? 5 : 4} value={value}
          onChange={e => onChange(e.target.value)} />
      </div>
    </div>
  );
}

function DoctorTab() {
  const [stage, setStage] = useState("draft");      // idle | loading | draft
  const [pid, setPid] = useState("p-001");
  const [source, setSource] = useState("audio");
  const [fields, setFields] = useState(SOAP_DRAFT.fields);
  const [progress, setProgress] = useState(0);
  const [approved, setApproved] = useState(false);

  const patient = PATIENTS.find(p => p.id === pid) || PATIENTS[0];

  function runDraft() {
    setApproved(false); setStage("loading"); setProgress(0);
    const steps = ["Transcribing audio (Whisper)…", "Reading patient wiki…", "Retrieving ICD-10 + guidelines…", "Drafting SOAP note…"];
    let i = 0;
    const t = setInterval(() => {
      i++; setProgress(Math.min(100, i * 25));
      if (i >= 4) { clearInterval(t); setFields(SOAP_DRAFT.fields); setTimeout(() => setStage("draft"), 350); }
    }, 600);
    window.__draftSteps = steps;
  }

  return (
    <div className="fade-in">
      <Intro icon="stethoscope" title={<>Consultation <span className="serif-i">documentation</span></>} tag="ship">
        Turn a spoken or typed consult into an approved SOAP note in under 60 seconds. You edit and approve — the note is never auto-filed.
      </Intro>

      <div className="doc-grid">
        {/* LEFT — inputs */}
        <div className="card" style={{ alignSelf: "start" }}>
          <div className="card-head"><Icon name="upload" size={17} color="var(--blue-600)" /><h3>Consult input</h3></div>
          <div className="card-pad col gap-16">
            <div>
              <label className="field-label">Patient ID</label>
              <select className="select mono-input" value={pid} onChange={e => setPid(e.target.value)}>
                {PATIENTS.map(p => <option key={p.id} value={p.id}>{p.id} · {p.name}</option>)}
              </select>
              <div className="row aic gap-8 mt-10" style={{ fontSize: 12.5, color: "var(--muted)" }}>
                <Pill kind="soft">{patient.age}{patient.sex}</Pill>
                <span>{patient.ward} · Bed {patient.bed}</span>
              </div>
            </div>

            <div>
              <label className="field-label">Source</label>
              <div className="seg">
                {[["audio", "mic", "Record"], ["upload", "upload", "Upload"], ["text", "doc", "Transcript"]].map(([k, ic, lb]) => (
                  <button key={k} className={"seg-btn" + (source === k ? " on" : "")} onClick={() => setSource(k)}>
                    <Icon name={ic} size={15} />{lb}
                  </button>
                ))}
              </div>
            </div>

            {source === "audio" && (
              <div className="rec-box">
                <div className="rec-dot" />
                <div className="grow">
                  <div style={{ fontWeight: 650, fontSize: 13.5, color: "var(--ink)" }}>consult_anjali.wav</div>
                  <div className="wave">{Array.from({ length: 34 }).map((_, i) => <span key={i} style={{ height: (6 + Math.abs(Math.sin(i * 1.3)) * 22) + "px" }} />)}</div>
                </div>
                <span className="mono" style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--muted)" }}>2:18</span>
              </div>
            )}
            {source === "upload" && (
              <div className="drop">
                <Icon name="upload" size={22} color="var(--blue-500)" />
                <div style={{ fontWeight: 600, fontSize: 13.5, marginTop: 6 }}>Drop audio file</div>
                <div className="muted fz12">.wav · .mp3 · .m4a — transcribed with Whisper large-v3</div>
              </div>
            )}
            {source === "text" && (
              <textarea className="textarea" rows={5} placeholder="Paste consult transcript…"
                defaultValue="Dr: How have you been? Pt: Getting headaches in the mornings, taking my amlodipine…" />
            )}

            <Btn kind="primary" icon="spark" className="btn-block" onClick={runDraft} disabled={stage === "loading"}>
              {stage === "loading" ? "Drafting…" : "Draft SOAP note"}
            </Btn>
            <div className="muted fz12" style={{ textAlign: "center" }}>Qwen3-32B on Groq · avg 41s</div>
          </div>
        </div>

        {/* RIGHT — draft */}
        <div className="col gap-16">
          {stage === "loading" && (
            <div className="card card-pad fade-in">
              <div className="row aic gap-10" style={{ marginBottom: 14 }}>
                <span className="spinner" /><strong style={{ fontFamily: "var(--font-head)" }}>Drafting note…</strong>
              </div>
              <ConfBar value={progress} />
              <div className="col gap-8 mt-14">
                {(window.__draftSteps || []).map((s, i) => (
                  <div key={i} className="row aic gap-8 fz13" style={{ color: progress >= (i + 1) * 25 ? "var(--success)" : "var(--muted)" }}>
                    <Icon name={progress >= (i + 1) * 25 ? "check" : "clock"} size={14} />{s}
                  </div>
                ))}
              </div>
            </div>
          )}

          {stage === "draft" && (
            <>
              {approved
                ? <Banner kind="ok">Approved & written to wiki page <IDToken>anjali-rao.md</IDToken></Banner>
                : <Banner kind="ok" icon="spark">Draft ready · review the four fields, then approve.</Banner>}

              <div className="card">
                <div className="card-head jcb">
                  <div className="row aic gap-10">
                    <Icon name="doc" size={17} color="var(--blue-600)" /><h3>SOAP note</h3>
                    <IDToken>soap-8b1745b5</IDToken>
                  </div>
                  <Pill kind="blue">draft</Pill>
                </div>
                <div className="card-pad col gap-14">
                  <SoapField letter="S" name="Subjective" value={fields.subjective} onChange={v => setFields({ ...fields, subjective: v })} />
                  <SoapField letter="O" name="Objective" value={fields.objective} onChange={v => setFields({ ...fields, objective: v })} />
                  <SoapField letter="A" name="Assessment" value={fields.assessment} onChange={v => setFields({ ...fields, assessment: v })} />
                  <SoapField letter="P" name="Plan" value={fields.plan} onChange={v => setFields({ ...fields, plan: v })} />
                </div>
              </div>

              {/* trust / citations panel */}
              <div className="card">
                <div className="card-head"><Icon name="spark" size={17} color="var(--blue-600)" /><h3>Confidence & citations</h3><span className="sub" style={{ marginLeft: "auto" }}>the audit trail</span></div>
                <div className="card-pad col gap-16">
                  <div>
                    <div className="row jcb aic" style={{ marginBottom: 7 }}>
                      <span className="field-label" style={{ margin: 0 }}>Model confidence</span>
                      <span className="muted fz12">model <span style={{ fontFamily: "var(--font-mono)" }}>{SOAP_DRAFT.model}</span></span>
                    </div>
                    <ConfBar value={SOAP_DRAFT.confidence} />
                  </div>

                  <div className="row aic gap-10 wrap-w">
                    <Pill kind="stable" dot>Referral not required</Pill>
                    <span className="muted fz12">Low-confidence or referral cases are surfaced loudly.</span>
                  </div>

                  <div>
                    <span className="field-label">ICD-10 candidates</span>
                    <div className="row gap-8 wrap-w">
                      {SOAP_DRAFT.icd.map(c => (
                        <span key={c.code} className="icd-chip">
                          <b>{c.code}</b> {c.label}<span className="icd-conf">{Math.round(c.conf * 100)}%</span>
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <span className="field-label">Source citations</span>
                    <div className="col gap-8">
                      {SOAP_DRAFT.citations.map((c, i) => (
                        <div key={i} className="cite-row">
                          <Icon name={c.tag === "wiki" ? "link" : "doc"} size={15} color="var(--blue-600)" />
                          <span className="grow"><b style={{ color: "var(--ink)" }}>{c.src}</b> <span className="muted">· {c.loc}</span></span>
                          <Pill kind={c.tag === "wiki" ? "blue" : "soft"}>{c.tag === "wiki" ? "LLM wiki" : "RAG"}</Pill>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="row gap-12">
                <Btn kind="success" icon="check" className="grow" onClick={() => setApproved(true)} disabled={approved}>
                  {approved ? "Approved" : "Approve & file to wiki"}
                </Btn>
                <Btn kind="danger-ghost" icon="x" onClick={runDraft}>Reject</Btn>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

window.DoctorTab = DoctorTab;
