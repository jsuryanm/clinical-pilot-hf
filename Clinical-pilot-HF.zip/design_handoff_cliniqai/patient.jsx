/* ===================== CliniqAI — Patient surface ===================== */

function Bubble({ m }) {
  const me = m.from === "user";
  return (
    <div className={"bub-row " + (me ? "me" : "bot")}>
      <div className={"bubble " + (me ? "b-me" : "b-bot")}>
        <div>{m.text}</div>
        {m.slots && (
          <div className="col gap-6 mt-10">
            {m.slots.map((s, i) => <button key={i} className="slot-btn">{s}</button>)}
          </div>
        )}
        {m.confirm && (
          <div className="confirm-card mt-10">
            <div className="row aic gap-8" style={{ fontWeight: 700, color: "#0ea672" }}><Icon name="check" size={15} />Confirmed</div>
            <div className="fz13 mt-6"><b>{m.confirm.doctor}</b> · {m.confirm.when}</div>
            <div className="row aic gap-6 mt-6" style={{ fontSize: 11.5, color: "var(--muted)" }}>
              <Icon name="bell" size={12} />Reminder set · ref <span style={{ fontFamily: "var(--font-mono)" }}>{m.confirm.ref}</span>
            </div>
          </div>
        )}
        <div className="bub-time">{m.time}{me && <Icon name="check" size={12} />}</div>
      </div>
    </div>
  );
}

function PatientTab() {
  const [msgs, setMsgs] = useState(CHAT_SEED);
  const [text, setText] = useState("");
  const [typing, setTyping] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [msgs, typing]);

  function now() { return new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", hour12: false }); }

  function botReply(userText) {
    const t = userText.toLowerCase();
    let reply;
    if (t.includes("book")) reply = { from: "bot", time: now(), text: "Sure! Here are the next open slots with Dr. Khanna:", slots: ["Wed 12 Jun · 10:30 AM", "Thu 13 Jun · 4:00 PM", "Fri 14 Jun · 11:15 AM"] };
    else if (t.includes("cancel")) reply = { from: "bot", time: now(), text: "Done — your appointment on Thu 13 Jun · 4:00 PM has been cancelled. A confirmation email is on its way. Would you like to rebook?" };
    else if (t.includes("reschedule") || t.includes("change")) reply = { from: "bot", time: now(), text: "No problem. Which day suits you better?", slots: ["Mon 16 Jun · 9:00 AM", "Tue 17 Jun · 2:30 PM"] };
    else reply = { from: "bot", time: now(), text: "Got it 👍 I've noted that. Is there anything else I can help with — booking, cancelling, or rescheduling?" };
    setTyping(true);
    setTimeout(() => { setTyping(false); setMsgs(m => [...m, reply]); }, 1100);
  }

  function send(t) {
    const val = (t ?? text).trim();
    if (!val) return;
    setMsgs(m => [...m, { from: "user", time: now(), text: val }]);
    setText("");
    botReply(val);
  }

  return (
    <div className="fade-in">
      <Intro icon="chat" title={<>Appointment <span className="serif-i">assistant</span></>} tag="ship">
        Patients book, change, or cancel conversationally. Warmer and simpler than the clinician surfaces — a friendly messaging experience (WhatsApp in production).
      </Intro>

      <div className="phone-stage">
        <div className="phone">
          {/* chat header */}
          <div className="chat-top">
            <div className="chat-avatar"><Quill size={20} /></div>
            <div className="grow">
              <div style={{ fontWeight: 700, fontSize: 14.5 }}>CliniqAI · Apollo Clinic</div>
              <div className="row aic gap-6" style={{ fontSize: 11.5, opacity: .85 }}><span className="live-dot" style={{ width: 6, height: 6 }} />online</div>
            </div>
            <Icon name="chat" size={18} color="rgba(255,255,255,.7)" />
          </div>

          {/* thread */}
          <div className="chat-thread" ref={scrollRef}>
            <div className="chat-date">Today</div>
            {msgs.map((m, i) => <Bubble key={i} m={m} />)}
            {typing && (
              <div className="bub-row bot"><div className="bubble b-bot typing"><span /><span /><span /></div></div>
            )}
          </div>

          {/* quick actions */}
          <div className="quick-row">
            {QUICK_ACTIONS.map(q => (
              <button key={q.label} className="quick-chip" onClick={() => send(q.reply)}>
                <Icon name={q.icon} size={14} />{q.label}
              </button>
            ))}
          </div>

          {/* composer */}
          <div className="composer">
            <input className="chat-input" placeholder="Type a message…" value={text}
              onChange={e => setText(e.target.value)} onKeyDown={e => e.key === "Enter" && send()} />
            <button className="send-btn" onClick={() => send()} aria-label="Send"><Icon name="send" size={18} color="#fff" /></button>
          </div>
        </div>

        <div className="phone-side">
          <h3 style={{ fontSize: 16 }}>Conversational, by design</h3>
          <p className="ink2 fz13 mt-6">Same handler code path as production WhatsApp — the demo just swaps the transport.</p>
          <div className="col gap-12 mt-18">
            {[["calendar", "Checks Google Calendar", "Live availability before proposing a slot."],
              ["bell", "Confirms & reminds", "Email confirmation now, reminder 24 h before."],
              ["users", "Manages waitlists", "Auto-offers freed slots to the next patient."]].map(([ic, t, d]) => (
              <div key={t} className="side-feat">
                <div className="side-ic"><Icon name={ic} size={16} color="var(--blue-700)" /></div>
                <div><div style={{ fontWeight: 650, fontSize: 13.5 }}>{t}</div><div className="muted fz12">{d}</div></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

window.PatientTab = PatientTab;
