/* ===================== CliniqAI — Nurse & Admin surface ===================== */

const PRIORITY_RANK = { urgent: 0, watch: 1, stable: 2 };
const STATUS_META = {
  done:     { pill: "done",     ico: "check",  label: "Done" },
  progress: { pill: "progress", ico: "refresh",label: "In progress" },
  queued:   { pill: "queued",   ico: "clock",  label: "Queued" },
  failed:   { pill: "failed",   ico: "x",      label: "Failed" },
  approve:  { pill: "approve",  ico: "alert",  label: "Awaiting approval" },
};

/* ---------- Handover ---------- */
function Handover() {
  const [generated, setGenerated] = useState(false);
  const rows = [...HANDOVER].sort((a, b) => PRIORITY_RANK[a.priority] - PRIORITY_RANK[b.priority]);
  const counts = rows.reduce((a, r) => (a[r.priority]++, a), { urgent: 0, watch: 0, stable: 0 });
  return (
    <div className="fade-in">
      <div className="row aic gap-12 wrap-w" style={{ marginBottom: 16 }}>
        <select className="select" style={{ maxWidth: 200 }} defaultValue="A"><option value="A">Gen Med — Ward A</option><option value="B">Gen Med — Ward B</option><option value="C">Cardiac Ward</option></select>
        <Btn kind="primary" icon="spark" onClick={() => setGenerated(true)}>Generate brief</Btn>
        <span className="soon-tag">Coming soon · teaser</span>
        {generated && <div className="row aic gap-8" style={{ marginLeft: "auto" }}>
          <Pill kind="urgent">{counts.urgent} urgent</Pill><Pill kind="watch">{counts.watch} watch</Pill><Pill kind="stable">{counts.stable} stable</Pill>
        </div>}
      </div>

      {!generated ? (
        <div className="empty-card"><Icon name="clipboard" size={26} color="var(--muted-2)" /><div style={{ fontWeight: 650, marginTop: 8 }}>No brief yet</div><div className="muted fz13">Pick a ward and generate a prioritised handover.</div></div>
      ) : (
        <div className="card fade-in">
          <div className="tbl-wrap" style={{ border: "none" }}>
            <table className="tbl">
              <thead><tr><th>Bed</th><th>Priority</th><th>Patient</th><th>Summary</th><th>Pending actions</th></tr></thead>
              <tbody>
                {rows.map(r => (
                  <tr key={r.id}>
                    <td><span style={{ fontFamily: "var(--font-mono)", fontWeight: 600 }}>{r.bed}</span></td>
                    <td><Pill kind={r.priority} dot>{r.priority}</Pill></td>
                    <td><div className="strong">{r.name}</div><IDToken>{r.id}</IDToken></td>
                    <td style={{ maxWidth: 320 }}>{r.one}</td>
                    <td>{r.pending.length ? <div className="col gap-6">{r.pending.map((p, i) => <span key={i} className="todo-chip"><Icon name="clock" size={12} />{p}</span>)}</div> : <span className="muted fz12">—</span>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------- Roster ---------- */
function Roster() {
  const [days, setDays] = useState(14);
  const [shiftId, setShiftId] = useState("");
  const [absent, setAbsent] = useState("");
  const [resolved, setResolved] = useState(false);
  return (
    <div className="fade-in col gap-16">
      <div className="row gap-16 wrap-w">
        <div className="card grow" style={{ minWidth: 280 }}>
          <div className="card-head"><Icon name="calendar" size={16} color="var(--blue-600)" /><h3>Generate roster</h3><span className="ship-tag" style={{ marginLeft: "auto" }}>Shipping</span></div>
          <div className="card-pad col gap-14">
            <div>
              <label className="field-label">Staff CSV</label>
              <div className="row aic gap-8"><span className="idtok" style={{ cursor: "default" }}>data/staff_roster.csv</span><span className="muted fz12">22 staff · 3 roles</span></div>
            </div>
            <div>
              <label className="field-label">Window — {days} days</label>
              <input type="range" min="7" max="28" value={days} onChange={e => setDays(+e.target.value)} className="range" />
            </div>
            <div className="row aic gap-12 wrap-w">
              <Btn kind="primary" icon="spark">Generate roster</Btn>
              <span className="muted fz12">greedy heuristic · &lt; 1 min</span>
            </div>
          </div>
        </div>
        <div className="card" style={{ minWidth: 200 }}>
          <div className="card-pad col gap-12" style={{ alignItems: "center", textAlign: "center" }}>
            <div className="field-label" style={{ margin: 0 }}>Fairness score</div>
            <div className="score-ring"><span>91</span></div>
            <Pill kind="stable" dot>Balanced load</Pill>
            <div className="muted fz12">1 unresolved conflict</div>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-head"><Icon name="users" size={16} color="var(--blue-600)" /><h3>14-day roster</h3><span className="sub" style={{ marginLeft: "auto" }}>showing 8 of 84 shifts</span></div>
        <div className="tbl-wrap" style={{ border: "none" }}>
          <table className="tbl">
            <thead><tr><th>Shift ID</th><th>Day</th><th>Shift</th><th>Staff</th><th>Role</th><th>Start</th><th>End</th><th>Cover</th></tr></thead>
            <tbody>
              {ROSTER.map(r => (
                <tr key={r.id}>
                  <td><IDToken>{r.id}</IDToken></td><td className="strong">{r.day}</td>
                  <td><Pill kind={r.shift === "Night" ? "soft" : "blue"}>{r.shift}</Pill></td>
                  <td className="strong">{r.staff}</td><td>{r.role}</td>
                  <td style={{ fontFamily: "var(--font-mono)" }}>{r.start}</td><td style={{ fontFamily: "var(--font-mono)" }}>{r.end}</td>
                  <td>{r.cover ? <Pill kind="watch">replacement</Pill> : <span className="muted">—</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="card">
        <div className="card-head"><Icon name="alert" size={16} color="var(--warning)" /><h3>Sick-call replacement</h3></div>
        <div className="card-pad">
          <div className="row gap-12 wrap-w" style={{ alignItems: "flex-end" }}>
            <div className="grow" style={{ minWidth: 160 }}><label className="field-label">Shift ID to cover</label><input className="input mono-input" placeholder="sh-3303" value={shiftId} onChange={e => setShiftId(e.target.value)} /></div>
            <div className="grow" style={{ minWidth: 160 }}><label className="field-label">Absent staff</label><input className="input" placeholder="K. Reddy" value={absent} onChange={e => setAbsent(e.target.value)} /></div>
            <Btn kind="primary" icon="refresh" onClick={() => setResolved(true)}>Find replacement</Btn>
          </div>
          {resolved && <div className="mt-14 fade-in"><Banner kind="ok">Replacement found in 9 min — <b>D. Kapoor</b> assigned to <span style={{ fontFamily: "var(--font-mono)" }}>{shiftId || "sh-3303"}</span>. Roster + fairness score updated.</Banner></div>}
        </div>
      </div>
    </div>
  );
}

/* ---------- Discharge ---------- */
function Discharge() {
  const [run, setRun] = useState(false);
  const done = DISCHARGE.filter(d => d.status === "done").length;
  return (
    <div className="fade-in">
      <div className="row aic gap-12 wrap-w" style={{ marginBottom: 16 }}>
        <input className="input mono-input" style={{ maxWidth: 180 }} defaultValue="p-006" />
        <Btn kind="primary" icon="spark" onClick={() => setRun(true)}>Start discharge</Btn>
        <span className="soon-tag">Coming soon · 2-of-5 teaser</span>
        {run && <span className="muted fz13" style={{ marginLeft: "auto" }}>{done}/5 streams complete</span>}
      </div>
      {!run ? (
        <div className="empty-card"><Icon name="doc" size={26} color="var(--muted-2)" /><div style={{ fontWeight: 650, marginTop: 8 }}>5 parallel streams</div><div className="muted fz13">Summary · Pharmacy · Family · Follow-up · Billing</div></div>
      ) : (
        <div className="stream-grid fade-in">
          {DISCHARGE.map((d, i) => {
            const m = STATUS_META[d.status];
            return (
              <div key={i} className={"stream-card s-" + d.status} style={{ animationDelay: i * 90 + "ms" }}>
                <div className="row aic jcb">
                  <div className="row aic gap-8"><span className={"stream-ic " + (d.status === "progress" ? "spin" : "")}><Icon name={m.ico} size={15} /></span><b style={{ fontSize: 13.5 }}>{d.stream}</b></div>
                  <Pill kind={m.pill}>{m.label}</Pill>
                </div>
                <div className="muted fz12 mt-10">{d.note}</div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ---------- Wiki health ---------- */
function WikiHealth() {
  const meta = { ok: ["stable", "Current"], stale: ["watch", "Stale"], broken: ["urgent", "Broken ref"] };
  return (
    <div className="fade-in card">
      <div className="card-head"><Icon name="link" size={16} color="var(--blue-600)" /><h3>Knowledge wiki — lint report</h3><span className="soon-tag" style={{ marginLeft: "auto" }}>Coming soon</span></div>
      <div className="tbl-wrap" style={{ border: "none" }}>
        <table className="tbl">
          <thead><tr><th>Page</th><th>Status</th><th>Detail</th><th>Updated</th></tr></thead>
          <tbody>
            {WIKI_HEALTH.map(w => (
              <tr key={w.page}>
                <td><IDToken>{w.page}</IDToken></td>
                <td><Pill kind={meta[w.status][0]} dot>{meta[w.status][1]}</Pill></td>
                <td>{w.note}</td><td className="muted">{w.updated}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function NurseTab() {
  const [sub, setSub] = useState("handover");
  const subs = [
    { id: "handover", label: "Handover", ship: false },
    { id: "roster", label: "Roster", ship: true },
    { id: "discharge", label: "Discharge", ship: false },
    { id: "wiki", label: "Wiki health", ship: false },
  ];
  return (
    <div className="fade-in">
      <Intro icon="clipboard" title={<>Operations <span className="serif-i">console</span></>} tag="ship">
        Run handover, rostering and discharge from one dense, scannable console. Rostering ships today; handover and discharge are wired through the orchestrator and previewed here.
      </Intro>
      <div className="subnav">
        {subs.map(s => (
          <button key={s.id} className={"sub-btn" + (sub === s.id ? " on" : "")} onClick={() => setSub(s.id)}>
            {s.label}{!s.ship && <span className="dot-soon" title="Coming soon" />}
          </button>
        ))}
      </div>
      {sub === "handover" && <Handover />}
      {sub === "roster" && <Roster />}
      {sub === "discharge" && <Discharge />}
      {sub === "wiki" && <WikiHealth />}
    </div>
  );
}

window.NurseTab = NurseTab;
